require('config') ------------------------------- Away load frist
require('PluginConfigs.lazy') ------------------- Plugin Manager
require('PluginConfigs.mason') ------------------ Language config
require('PluginConfigs.neotree') ---------------- Nerd tree
require('PluginConfigs.floaterm') --------------- Pop-up terminal
require('PluginConfigs.lualine') ---------------- Status bar
require('PluginConfigs.coc') -------------------- Auto Complete
require('PluginConfigs.treesitter') ------------- Highlight code support
require('PluginConfigs.autoclose') -------------- Auto Close brackets
require('PluginConfigs.telescope') -------------- Finder
require('PluginConfigs.blankline') -------------- Tab Highlight
require('PluginConfigs.which-key') --------------Leader-guide--Default 
-------------------- Themes ---------------------
require('Themes.catppuccin')

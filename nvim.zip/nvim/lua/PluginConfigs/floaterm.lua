--          ______            __                    
--         / __/ /___  ____ _/ /____  _________ ___ 
--        / /_/ / __ \/ __ `/ __/ _ \/ ___/ __ `__ \
--       / __/ / /_/ / /_/ / /_/  __/ /  / / / / / /
--      /_/ /_/\____/\__,_/\__/\___/_/  /_/ /_/ /_/ 

vim.g.floaterm_height = 0.99
vim.g.floaterm_width  = 0.4
vim.g.floaterm_position = 'topright'
vim.g.floaterm_wintype= 'floatfloat'
vim.cmd([[
  hi Floaterm guibg=black
  hi FloatermBorder guibg=cyan guifg=purple
]])
